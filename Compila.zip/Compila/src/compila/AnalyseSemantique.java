/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compila;

import static compila.AnalyseLexical.estUnEntier;
import static compila.AnalyseLexical.estUnID;
import static compila.AnalyseLexical.estUnMcarReserver;
import static compila.AnalyseLexical.estUnReel;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.swing.JTextArea;

/**
 *
 * @author hp
 */
public class AnalyseSemantique {
    private final String motR[] = {"Int_Number","Give","Real_Number","If","Else","Start","Affect","to","Give","Finish","ShowMes","ShowVal","End_Program","Start_Program","to"};
    private final String crR[] = {";;","//.","--",":",","};
    private ArrayList<String>liste = new ArrayList();
    private StringTokenizer token;
    private boolean block = false;
    private int nombreBlock = 0;
    private boolean p = false ,activeElse = false ;
    private String var1,var2,var3,ss;
    
    public void juste(int i,JTextArea txtra){
        txtra.append(liste.get(i) + "     ----------> Syntaxe juste\n");
        
    }
   
    public void remplirListe(File file){
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            // Remplir chaque ligne dans la liste
            while ((line = br.readLine()) != null) {
                liste.add(line);         
            }      
            br.close(); // fermeture du fichier
            //System.out.println(liste.get(3));
        } catch (FileNotFoundException ex) {
            Tools.msgBox("Fichier chargé introuvable " + ex);
        } catch (IOException ex) {
            Tools.msgBox("Erreur de la lecture du fichier" + ex);
        }
    }
    String msg;
    public boolean affectationA(StringTokenizer token, String t){
        if(t.equals("Affect")&&(token.hasMoreTokens())){
            t = token.nextToken();
            if(t.equals(" ")&&(token.hasMoreTokens())){
                    t = token.nextToken();
                    if(estUnID(t) && !estUnMcarReserver(t , motR)&&(token.hasMoreTokens())){
                        var2 = t;
                        t = token.nextToken();
                        if(t.equals(" ")&&(token.hasMoreTokens())){
                            t = token.nextToken();
                            if(t.equals("to")&&(token.hasMoreTokens())){
                                t = token.nextToken();
                                if(t.equals(" ")&&(token.hasMoreTokens())){
                                    t = token.nextToken();
                                    if(estUnID(t) && !estUnMcarReserver(t , motR)&&(token.hasMoreTokens())){
                                        var1 =t;
                                        t = token.nextToken();
                                        if(t.equals(" ")&&(token.hasMoreTokens())){
                                            t = token.nextToken();
                                            if(t.equals(";;")){
                                                if(!token.hasMoreTokens()) {
                                                    ss = var1+" = "+var2+" ;";
                                                    return true;
                                                }
                                                else msg = "  --/ Erreur aprés la syntax '" + t + "'";
                                            }
                                            else msg = "  --/ Erreur de la syntax '" + t + "' aprés Id";
                                        }
                                        else msg = "  --/ Erreur de la syntax '" + t + "' espace obligatoire aprés Id";
                                    }
                                    else msg = "  --/ Erreur de la syntax '" + t + "' aprés 'to'";
                                }
                                else msg = "  --/ Erreur de la syntax '"+t+"' espace obligatoire aprés 'to'";
                            }
                            else msg = "  --/ Erreur de la syntaxe '" + t + "' aprés Id";
                        }
                        else msg = "  --/ Erreur de la syntax '"+t+"' espace obligatoire aprés 'id'";
                    }
                    else msg = "  --/ Erreur de la syntax '"+ t +"' aprés 'Give'";
            }
            else msg = "  --/ Erreur de la syntax '"+t+"' espace obligatoire aprés 'Affect'";
        }
        return false;
    }
    public boolean affectationG(StringTokenizer token, String t){
        if(t.equals("Give")&&(token.hasMoreTokens())){
            t = token.nextToken();
            if(t.equals(" ")&&(token.hasMoreTokens())){
                    t = token.nextToken();
                    if(estUnID(t) && !estUnMcarReserver(t , motR)&&(token.hasMoreTokens())){
                        var1 =t;
                        t = token.nextToken();
                        if(t.equals(" ")&&(token.hasMoreTokens())){
                            t = token.nextToken();
                            if(t.equals(":")&&(token.hasMoreTokens())){
                                t = token.nextToken();
                                if(t.equals(" ")&&(token.hasMoreTokens())){
                                    t = token.nextToken();
                                    if((estUnEntier(t) || estUnReel(t))&&(token.hasMoreTokens())){
                                        var2 = t;
                                        t = token.nextToken();
                                        if(t.equals(" ")&&(token.hasMoreTokens())){
                                            t = token.nextToken();
                                            if(t.equals(";;")){
                                                if(!token.hasMoreTokens()) {
                                                    ss = var1+" = "+var2+" ;";
                                                    return true;
                                                }
                                                else msg = "  --/ Erreur aprés la syntax '" + t + "'";
                                            }
                                            else msg = "  --/ Erreur de la syntax '" + t + "' aprés la valeur";
                                        }
                                        else msg = "  --/ Erreur de la syntax '" + t + "' espace obligatoire aprés la valeur";
                                    }
                                    else msg = "  --/ Erreur de la syntax '" + t + "' aprés ':'";
                                }
                                else msg = "  --/ Erreur de la syntax '"+t+"' espace obligatoire aprés ':'";
                            }
                            else msg = "  --/ Erreur de la syntaxe '" + t + "' aprés Id";
                        }
                        else msg = "  --/ Erreur de la syntax '"+t+"' espace obligatoire aprés 'id'";
                    }
                    else msg = "  --/ Erreur de la syntax '"+ t +"' aprés 'Give'";
            }
            else msg = "  --/ Erreur de la syntax '"+t+"' espace obligatoire aprés 'Give'";
        }
        return false;
    }
    public boolean ecritureM(StringTokenizer token, String t){
        if(t.equals("ShowMes")&&(token.hasMoreTokens())){
            t = token.nextToken();
            if(t.equals(" ")&&(token.hasMoreTokens())){
                t = token.nextToken();
                if(t.equals(":")&&(token.hasMoreTokens())){
                    t = token.nextToken();
                    if(t.equals(" ")&&(token.hasMoreTokens())){
                        t = token.nextToken();
                        if(t.equals("\"")&&(token.hasMoreTokens())){
                            var1="";
                            t = token.nextToken();
                            while(token.hasMoreTokens() && !t.equals("\"")){
                                var1+= t;
                                t = token.nextToken();
                            }
                            if(t.equals("\"")){
                                t = token.nextToken();
                                if(t.equals(" ")&&(token.hasMoreTokens())){
                                        t = token.nextToken();
                                        if(t.equals(";;")){
                                            if(!token.hasMoreTokens()) {
                                                ss = "System.out.println(\""+ var1 +"\") ;";
                                                return true;
                                            }
                                            else msg = "  --/ Erreur de la syntax '" + t + "'";
                                        }
                                        else msg = "  --/ Erreur de la syntax '" + t + "' aprés '\"'";
                                }
                                else msg = "  --/ Erreur de la syntax '" + t + "' aprés '\"' espace obligatoire";
                            }
                            else msg = "  --/ Erreur de la syntax '" + t + "' nessesite un '\"' aprés l\'affichage";
                            }   
                        }
                        else msg = "  --/ Erreur de la syntax '" + t + "' aprés ':'";
                    }
                    else msg = "  --/ Erreur de la syntax '" + t + "' apré : éspace obligatoire";
                }
                else msg = "  --/ Erreur de la syntax '" + t + "' aprés 'ShowMes'";
            }
            else msg = "  --/ Erreur de la syntax '" + t + "' aprés 'ShowMes' espace obligatoire";
        return false;
    }
    public boolean ecritureV(StringTokenizer token, String t){
        if(t.equals("ShowVal")&&(token.hasMoreTokens())){
            t = token.nextToken();
            if(t.equals(" ")&&(token.hasMoreTokens())){
                    t = token.nextToken();
                    if(t.equals(":")&&(token.hasMoreTokens())){
                        t = token.nextToken();
                        if(t.equals(" ")&&(token.hasMoreTokens())){
                            t = token.nextToken();
                            if(estUnID(t) && !estUnMcarReserver(t , motR)&&(token.hasMoreTokens())){
                                var1 = t ;
                                t = token.nextToken();
                                if(t.equals(" ")&&(token.hasMoreTokens())){
                                    t = token.nextToken();
                                    if(t.equals(";;")){
                                       if(token.hasMoreTokens()) {
                                           msg = "  --/ Erreur aprés la syntax '" + t + "'";
                                           return false;
                                       }
                                       else {
                                           ss="System.out.println("+ var1 +") ;";
                                           return true;
                                       }
                                    }
                                    else msg = "  --/ Erreur aprés la variable '" + t + "'";
                                }
                                else msg = "  --/ Erreur espace obligatoire aprés la variable '" + t + "'";
                            }
                            else msg = "  --/ Erreur d'identificateur '" + t + "'";
                        }
                        else msg = "  --/ Erreur espace obligatoire aprés la syntax ':'";
                    }
                    else msg = "  --/ Erreur de la syntax '"+t+"' 'ShowVal'";
            }
            else msg = "  --/ Erreur espace obligatoire aprés 'ShowVal'";
        }
        return false;
    }
    public boolean estUnCommentaire(StringTokenizer token, String t){
        if(t.equals("//.")){
            var1 = "";
            t = token.nextToken();
            var1=t;
            while(token.hasMoreTokens() && !t.equals("\"")){
                                
                                t = token.nextToken();
                                var1+= t;                  
            }
            ss = "//"+var1;
            return true;
        }
        msg = "  --/ Erreur de symbole '"+t+"'";
        return false;
    }
    public boolean declarationReel(StringTokenizer token, String t){
        if(t.equals("Real_Number")&&(token.hasMoreTokens())){
            t = token.nextToken();
            if(t.equals(" ")&&(token.hasMoreTokens())){
                    t = token.nextToken();
                    if(t.equals(":")&&(token.hasMoreTokens())){
                        t = token.nextToken();
                        if(t.equals(" ")&&(token.hasMoreTokens())){
                            t = token.nextToken();
                            if(estUnID(t) && !estUnMcarReserver(t , motR)&&(token.hasMoreTokens())){
                                var1 = t ;
                                /////////////////////
                                t = token.nextToken();
                                while(token.hasMoreTokens() && t.equals(",")){
                                    t = token.nextToken();
                                    if(estUnID(t) && !estUnMcarReserver(t , motR)){
                                        var1+= ", "+t;
                                         t = token.nextToken();
                                    }
                                    else {
                                        msg = "   --/ Erreur identificateur '"+ t +"' non reconnu ";
                                        return false;
                                    }
                                }
                                //////////////////////
                                if(t.equals(" ")&&(token.hasMoreTokens())){
                                    t = token.nextToken();
                                    if(t.equals(";;")){
                                        if(token.hasMoreTokens()){
                                            msg = "  --/ Erreur aprés la syntax '" + t + "'";
                                            return false;
                                        }
                                        else {
                                            ss = "double "+var1+" ;";
                                            return true;
                                        }
                                    }
                                    else{
                                        msg = "  --/ Erreur manque de '"+t+"' a la fin d'instruction";
                                        return false;
                                    }
                                }
                                else {
                                    msg = "  --/ Erreur manque d'espace aprés '"+t+"'";
                                    return false;
                                }
                            }
                            else {
                                msg = "  --/ Erreur de déclaration d'identificateur '"+t+"' aprés :";
                                return false;
                            }
                        }
                        else{
                            msg = "  --/ Erreur manque d'espace aprés ':'";
                            return false;
                        }
                    }
                    else{
                        msg = "  --/ Erreur '" + t + "' manque de : aprés Real_Number";
                        return false;
                    }
                }
            else{
                msg = "  --/ Erreur manque d'espace aprés Real_Number";
                return false;
            }
        }     
        return false;
    }
    public boolean declarationEntiere(StringTokenizer token, String t){
        if(t.equals("Int_Number")&&(token.hasMoreTokens())){
            t = token.nextToken();
            if(t.equals(" ")&&(token.hasMoreTokens())){
                    t = token.nextToken();
                    if(t.equals(":")&&(token.hasMoreTokens())){
                        t = token.nextToken();
                        if(t.equals(" ")&&(token.hasMoreTokens())){
                            t = token.nextToken();
                            if(estUnID(t) && !estUnMcarReserver(t , motR) &&(token.hasMoreTokens())){
                                var1 = t ;
                                /////////////////////
                                t = token.nextToken();
                                while(token.hasMoreTokens() && t.equals(",")){
                                    
                                    t = token.nextToken();
                                    if(estUnID(t) && !estUnMcarReserver(t , motR)){
                                        var1+= ", "+t;
                                         t = token.nextToken();
                                    }
                                    else {
                                        msg = "   --/ Erreur identificateur '"+ t +"' non reconnu ";
                                        return false;
                                    }
                                }
                                //////////////////////
                                if(t.equals(" ")&&(token.hasMoreTokens())){
                                    t = token.nextToken();
                                    if(t.equals(";;")){
                                        if(token.hasMoreTokens()){
                                            msg = "  --/ Erreur aprés la syntax '" + t + "'";
                                            return false;
                                        }
                                        else {
                                            ss = "int "+var1+" ;";
                                            return true;
                                        }
                                    }
                                    else{
                                        msg = "  --/ Erreur manque de '"+t+"' a la fin d'instruction";
                                        return false;
                                    }
                                }
                                else {
                                    msg = "  --/ Erreur manque d'espace aprés '"+t+"'";
                                    return false;
                                }
                            }
                            else {
                                msg = "  --/ Erreur de déclaration d'identificateur '"+t+"' aprés :";
                                return false;
                            }
                        }
                        else{
                            msg = "  --/ Erreur manque d'espace aprés ':'";
                            return false;
                        }
                    }
                    else{
                        msg = "  --/ Erreur '" + t + "' manque de : aprés Int_Number";
                        return false;
                    }
                }
            else{
                msg = "  --/ Erreur manque d'espace aprés Int_Number";
                return false;
            }
        }     
        return false;
    }
    public boolean conditionIf(StringTokenizer token, String t){
        if(t.equals("If")&&(token.hasMoreTokens())){
            var3 = "";
            t = token.nextToken();
            if(t.equals(" ")&&(token.hasMoreTokens())){
                    t = token.nextToken();
                    if(t.equals("--")&&(token.hasMoreTokens())){
                        t = token.nextToken();
                        if(t.equals(" ")&&(token.hasMoreTokens())){
                            t = token.nextToken();
                            if(estUnID(t) && !estUnMcarReserver(t , motR)&&(token.hasMoreTokens())){
                                var3 = t;
                                t = token.nextToken();
                                if((t.equals("<") || t.equals(">") || t.equals("="))&&(token.hasMoreTokens())){
                                    if(t.equals("<")){
                                        var3+= " <";
                                    }
                                    else if(t.equals(">")){
                                        var3+= " >";
                                    }
                                    else if(t.equals("=")){
                                        var3+= " ==";
                                    }
                                    t = token.nextToken();
                                    if(((estUnID(t) && !estUnMcarReserver(t , motR)) || estUnEntier(t) || estUnReel(t))&&(token.hasMoreTokens())){
                                        var3+= " "+t;
                                        t = token.nextToken();
                                        if(t.equals(" ") && (token.hasMoreTokens())){
                                            t = token.nextToken();
                                            if(t.equals("--")){
                                                if(!token.hasMoreTokens()){
                                                    block = true;
                                                    activeElse = true;
                                                    return true;
                                                }
                                                else{
                                                    t = token.nextToken();
                                                    if(t.equals(" ")){
                                                        t = token.nextToken();
                                                        if(declarationEntiere(token,t)||declarationReel(token,t)||affectationG(token,t)||affectationA(token,t)||ecritureM(token,t)||ecritureV(token,t)||estUnCommentaire(token,t)){
                                                            activeElse=true;
                                                            return true;
                                                        }
                                                        else msg = "  --/ Erreur aprés la syntax '" + t + "'"; 
                                                    }
                                                    else msg = "  --/ Erreur aprés la syntax '" + t + "'";
                                                }                                              
                                            }
                                            else msg = "  --/ Erreur de la syntax '" + t + "' aprés la valeur";
                                        }
                                        else msg = "  --/ Erreur de la syntax '" + t + "' espace obligatoire aprés la valeur";
                                    }
                                    else msg = "  --/ Erreur de la syntax '" + t + "' aprés ':'";
                                }
                                else msg = "  --/ Erreur de la syntax '"+t+"' espace obligatoire aprés ':'";
                            }
                            else msg = "  --/ Erreur de la syntaxe '" + t + "' aprés Id";
                        }
                        else msg = "  --/ Erreur de la syntax '"+t+"' espace obligatoire aprés 'id'";
                    }
                    else msg = "  --/ Erreur de la syntax '"+ t +"' aprés 'Give'";
            }
            else msg = "  --/ Erreur de la syntax '"+t+"' espace obligatoire aprés 'Give'";
        }
        return false;
    }
    public boolean conditionElse(StringTokenizer token, String t){
        if(t.equals("Else")&& activeElse){
            if(!token.hasMoreTokens()){
                block = true;
                activeElse = false;
                return true;
            }
            else{
                t = token.nextToken();
                if(t.equals(" ")&&(token.hasMoreTokens())){
                    t = token.nextToken();
                    if(declarationEntiere(token,t)||declarationReel(token,t)||affectationG(token,t)||affectationA(token,t)||ecritureM(token,t)||ecritureV(token,t)||estUnCommentaire(token,t)){
                        activeElse = false;
                        return true;
                    }
                    else msg = "  --/ Erreur aprés la syntax '" + t + "'"; 
                }
                else msg = "  --/ Erreur aprés la syntax '" + t + "'";
            }
        }
        return false;
    }
    public boolean blockDebut(StringTokenizer token, String t){
        if(t.equals("Start") && !token.hasMoreTokens() && (block == true)){
            if(activeElse) p = true;
            else p = false;
            block = false ; 
            nombreBlock++ ;
            return true;
        }
        else msg = "  --/ Erreur de la syntax '" + t + "'"; 
        return false;
    }
    public boolean blockFin(StringTokenizer token, String t){
        if(t.equals("Finish") && (!token.hasMoreTokens()) && (nombreBlock > 0)){ 
            nombreBlock-- ;
            if(p) activeElse = true;
            else activeElse = false;
            return true;
        }
        else msg = "  --/ Erreur de la syntax '" + t + "'"; 
        return false;
    }
    
    public void analyseur(JTextArea txtra){
        int n = liste.size() - 1;
        token = new StringTokenizer(liste.get(0));
        String t = token.nextToken();
        if(t.equals("Start_Program")&&(!token.hasMoreTokens())) txtra.append("public static void main(String[] args) {\n");
        else txtra.append("'" + t + "' Erreur de la syntax monque debut du programme");
        
        /////////////////////////////////////////////////
        /////////////////////////////////////////////////
        for (int i = 1; i < liste.size()-1; i++) {
            if(liste.get(i).isEmpty());
            else{
                token = new StringTokenizer(liste.get(i)," ,<>=" , true);
                t = token.nextToken();

                if(declarationEntiere(token,t)){  // Travaille avec succées
                    activeElse = false;
                    txtra.append("int "+var1+" ;\n");
                }

                else if(declarationReel(token,t)){ //if(t.equals("Real_Number")){   
                    activeElse = false;
                    txtra.append("double "+var1+" ;\n");
                }
                else if(affectationG(token,t)){
                    activeElse = false;
                    txtra.append(var1+" = "+var2+ " ;\n");
                }
                else if(affectationA(token,t)){
                    activeElse = false;
                    txtra.append(var1+" = "+var2+ " ;\n");
                }
                else if(ecritureM(token,t)){
                    activeElse = false;
                    txtra.append("System.out.println(\""+ var1 +"\") ;\n");
                }
                else if(ecritureV(token,t)){
                    activeElse = false;
                    txtra.append("System.out.println("+ var1 +") ;\n");
                }
                else if(estUnCommentaire(token,t)){
                    activeElse = false;
                    txtra.append("//"+var1+"\n");
                }
                else if(conditionIf(token,t)){
                    txtra.append("if ( "+var3+" ) "+ss+"\n");
                }
                else if(conditionElse(token,t)){
                    txtra.append("else "+ss+"\n");
                }
                else if(blockDebut(token,t)){
                    txtra.append("{\n");
                }
                else if(blockFin(token,t)){
                    txtra.append("}\n");
                }
                else txtra.append("Erreur a la ligne "+(i+1)+"\n");
                msg = "";
                ss = "";
            }
            
	}
        
        //////////////////////////////////////////////
        ////////////////////////////////////////////////
        token = new StringTokenizer(liste.get(n));
        t = token.nextToken();
        if(t.equals("End_Program") && (!token.hasMoreTokens())){
            if(nombreBlock == 0){
                txtra.append("}\n");
            }
            else txtra.append("'" + t + "' Erreur de la syntax monque '"+nombreBlock+"' Finish avant End_Program\n");
        }
        else txtra.append("'" + t + "' Erreur de la syntax monque End_Program a la fin du programme\n");
    }
}
