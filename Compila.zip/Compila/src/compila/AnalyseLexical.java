package compila;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.swing.JTextArea;

public class AnalyseLexical {
    private final String s = "" ;
    private final char nm[] = {'0','1','2','3','4','5','6','7','8','9'};
    private final char cs[] = {'_','-'};
    private final char cr[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
    private final String motR[] = {"Int_Number","Give","Real_Number","If","Else","Start","Affect","to","Give","Finish","ShowMes","ShowVal","End_Program","Start_Program","to"};
    private final String crR[] = {";;","//.","--",":",","};
    File fichier = new File("fichier.compila");
    ArrayList<String>liste = new ArrayList();
    StringTokenizer token;

    public static boolean estUnMcarReserver(String c , String[] a){
        for(int i=0;i<a.length;i++){
            if(c.equals(a[i])) return true;
        }
        return false;
    }
    public static boolean estUnEntier(String chaine) {
		try {
			Integer.parseInt(chaine);
		} catch (NumberFormatException e){
			return false;
		}
 
		return true;
    }
    public static boolean estUnReel(String chaine) {
		try {
			Double.parseDouble(chaine);
		} catch (NumberFormatException e){
			return false;
		}
 
		return true;
    }
    public static boolean estUnCar(char c , char v[]){
        for(int i=0;i<v.length;i++){
            if(c==v[i]) return true;
        }
        return false;
    }
    public static boolean estUnID(String s){
        boolean a = false;
            int i;
            if(Character.isLetter(s.charAt(0))){
                if(s.length()==1) return true;
                else for(i=1;i<s.length();i++){
                    if((Character.isLetter(s.charAt(i))) || (s.charAt(i)=='_') || (Character.isDigit(s.charAt(i)))){
                        a = true;
                    }
                    else return false;
                }
                return a;
            }
            else return false;   
    }
    public void remplirListe(File file){
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            // Remplir chaque ligne dans la liste
            while ((line = br.readLine()) != null) {
                liste.add(line);         
            }      
            br.close(); // fermeture du fichier
            //System.out.println(liste.get(3));
        } catch (FileNotFoundException ex) {
            Tools.msgBox("Fichier chargé introuvable "+ex);
        } catch (IOException ex) {
            Tools.msgBox("Erreur de la lecture du fichier"+ex);
        }
    }
    public void analyse(JTextArea txtra){
        for (String temp : liste) {
            //System.out.println(temp);
            token = new StringTokenizer(temp , " ,<>=" , true);
            while(token.hasMoreTokens()){
                //System.out.println(token.nextToken());
                String mot = token.nextToken();
                if(mot.equals("Start_Program")) txtra.append(mot + "  ----> Mot réservé : début du programme\n");
                else if(mot.equals("Int_Number")) txtra.append(mot + "  ----> Mot réservé : Déclaration des entiers\n");
                else if(mot.equals("Real_Number")) txtra.append(mot + "  ----> Mot réservé : Déclaration des réels\n");
                else if(mot.equals("Give")) txtra.append(mot + "  ----> Mot réservé : Affectation d'une valeure\n");
                else if(mot.equals("Affect")) txtra.append(mot + "  ----> Mot réservé : Affectation d'une variable a une autre\n");
                else if(mot.equals("to")) txtra.append(mot + "  ----> Mot réservé : Reçoit\n");
                else if(mot.equals("ShowMes")) txtra.append(mot + "  ----> Mot réservé : Affichage d'un message\n");
                else if(mot.equals("ShowVal")) txtra.append(mot + "  ----> Mot réservé : Affichage d'une valeure\n");
                else if(mot.equals("End_Program")) txtra.append(mot + "  ----> Mot réservé : fin du programme\n");
                else if(mot.equals("If")) txtra.append(mot + "  ----> Mot réservé : Condition si\n");
                else if(mot.equals("Else")) txtra.append(mot + "  ----> Mot réservé : Condition sinon\n");
                else if(mot.equals("Start")) txtra.append(mot + "  ----> Mot réservé : Début d'un bloc\n");
                else if(mot.equals("Finish")) txtra.append(mot + "  ----> Mot réservé : Fin d'un bloc\n");
                else if(mot.equals(":")) txtra.append(mot + "  ----> Caractère réservé\n");
                else if(mot.equals(",")) txtra.append(mot + "  ----> Caractère réservé : Séparateur de variables\n");
                else if(mot.equals(";;")) txtra.append(mot + "  ----> Caractère réservé : Fin d'instruction\n");
                else if(mot.equals("--")) txtra.append(mot + "  ----> Caractère réservé : bloc de condition\n");
                else if(mot.equals("<")) txtra.append(mot + "  ----> Caractère réservé : Opérateur logique : inférieur\n");
                else if(mot.equals(">")) txtra.append(mot + "  ----> Caractère réservé : Opérateur logique : superieur\n");
                else if(mot.equals("=")) txtra.append(mot + "  ----> Caractère réservé : Opérateur logique : égale\n");
                else if(mot.equals("\"")){
                    txtra.append(mot + "  ----> Caractère reserver : bloc de chaine de caractère\n");
                    while(token.hasMoreTokens()) {
                        mot = token.nextToken();
                        if(mot.equals("\"")){
                            break;
                        }
                        else{
                            txtra.append(mot + "");
                        }    
                    } 
                    txtra.append(" ----> Affichage du text\n");
                    txtra.append(mot + " ----> Caractère réservé : bloc de chaine de caractère\n");
                }
                else if(mot.equals("//.")) {
                    txtra.append(mot + "  ----> Caractère réservé : Commentaire\n");
                    while(token.hasMoreTokens()) {
                        mot = token.nextToken();
                        txtra.append(mot + "");
                    } 
                    txtra.append(" ----> Commentaire\n");
                }
                else if(AnalyseLexical.estUnID(mot))txtra.append(mot + "  ----> Identificateur\n");
                else if(AnalyseLexical.estUnEntier(mot))txtra.append(mot + "  ----> Entier\n");
                else if(AnalyseLexical.estUnReel(mot))txtra.append(mot + "  ----> Réel\n");
                else if(!mot.equals(" ")) txtra.append(mot + "  ----> Erreur\n");
            }
            
	}
    }
}
